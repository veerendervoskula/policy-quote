import express from 'express';
import { handler } from '../lambda';
import { asyncHandler } from '../middleware/errorHandler';

const app = express();

app.use(express.json());

app.post(
  '/policy/quote',
  asyncHandler(async (req, res) => {
    const result =
      await handler(
        {
          body: JSON.stringify(req.body)
        } as any,
        {} as any
      );

    res
      .status(result.statusCode)
      .json(
        JSON.parse(result.body)
      );
  })
  );
